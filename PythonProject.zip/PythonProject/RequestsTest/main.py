import requests

URL = 'https://api.pokemonbattle.ru/v2'
TOKEN ='443f38b2567214116a9deb765dfa934c'
HEADER = {
    'Content-Type' : 'application/json',
    'trainer_token' : TOKEN}
body = {
    "name": "Tigi",
    "photo_id": 36}

body_name = {
    "pokemon_id": "103006",
    "name": "MONOLIZZO",
    "photo_id": 36
}

body_pokeboll = {
    "pokemon_id": "103006"
}

#response = requests.post(url=f'{URL}/pokemons', headers = HEADER, json = body)
#print(response.text) #Создание покемона POST /pokemons

#response = requests.put(url=f'{URL}/pokemons', headers = HEADER, json = body_name)
#print(response.text) #Смена имени покемона PUT /pokemons

response_boll = requests.post(url=f'{URL}/trainers/add_pokeball', headers = HEADER, json = body_pokeboll)
print(response_boll.text)  #Поймать покемона в покебол (POST /trainers/add_pokebal